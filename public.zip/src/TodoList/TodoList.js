import React, {Component} from 'react';
import './TodoList.css';
import TodoListItem from "../TodoListItem/TodoListItem";

class TodoList extends Component {

	render() {
		let {tasks} = this.props;
		let element = tasks.map(item => {
			let isImportant = {
				text: item.text,
				key: item.id,
			};
			return (<TodoListItem isImportant={isImportant}/>);
		});
		return (
			<ul className="list-group">
				{element}
			</ul>
		);
	}
}

export default TodoList;