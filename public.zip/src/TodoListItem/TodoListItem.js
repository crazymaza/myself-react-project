import React, {Component} from 'react';
import './TodoListItem.css';

class TodoListItem extends Component {
	constructor(props) {
		super(props);
		this.state = {
			done: '',
			important: false
		}
	}

	//Зачёркиваем элемент.
	setDone = () => {
		this.setState((state) => {
			return {done: !state.done}
		});
	};

	//Делаем элемент важным.
	setImportant = () => {
		this.setState((state) =>{
			return {important: !state.important};
		})
	};

	render() {
		let {key, text} = this.props.isImportant;
		return (
			<div key={key}>
				<li className="list-group-item d-flex justify-content-between align-items-center">
					<span className={`${this.state.important ? 'important-text' : ''} ${this.state.done ? 'done' : ''}`}
					      onClick={this.setDone}>{text}</span>
					<div>
						<i className={`fa fa-star ${this.state.important ? 'important-star' : ''}`} aria-hidden="true"
						   onClick={this.setImportant}/>
						<i className="fa fa-trash" aria-hidden="true"/>
					</div>
				</li>
			</div>
		);
	}
}

export default TodoListItem;